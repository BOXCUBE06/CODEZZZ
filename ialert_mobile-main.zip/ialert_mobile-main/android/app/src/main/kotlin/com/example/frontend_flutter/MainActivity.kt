package com.example.frontend_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
