import 'package:flutter/material.dart';
import '../components/live_map.dart'; // Import Shared Map

class StudentMapView extends StatelessWidget {
  const StudentMapView({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // 1. SHARED MAP WIDGET
        const LiveMapWidget(showAllAlerts: false),

        // 2. STATUS CARD OVERLAY
        Positioned(
          bottom: 20,
          left: 20,
          right: 20,
          child: Card(
            elevation: 6,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.my_location, color: Colors.blue),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "You are visible",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          "Responders can track your location.",
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
