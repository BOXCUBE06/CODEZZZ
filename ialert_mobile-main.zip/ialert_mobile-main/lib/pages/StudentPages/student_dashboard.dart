import 'package:flutter/material.dart';
import '../components/profile_icon.dart'; // Shared Profile Button

// Import the 3 Views
import '../StudentPages/student_home.dart';
import '../StudentPages/student_map.dart';
import '../StudentPages/student_notification.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  int _currentIndex = 1;
  final List<Widget> _pages = [
    const StudentMapView(),
    const StudentHomeView(),
    const StudentNotifView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "iAlert Student",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.red[700],
        centerTitle: true,
        actions: const [ProfileIconButton()],
      ),

      body: IndexedStack(index: _currentIndex, children: _pages),

      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        backgroundColor: Colors.red.shade50,
        indicatorColor: Colors.red.shade200,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.location_on_outlined),
            selectedIcon: Icon(Icons.location_on, color: Colors.red),
            label: 'Location',
          ),
          NavigationDestination(
            icon: Icon(Icons.emergency_outlined, color: Colors.red, size: 30),
            selectedIcon: Icon(Icons.emergency, color: Colors.white, size: 30),
            label: 'PANIC',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_outlined),
            selectedIcon: Icon(Icons.notifications, color: Colors.red),
            label: 'Updates',
          ),
        ],
      ),
    );
  }
}
