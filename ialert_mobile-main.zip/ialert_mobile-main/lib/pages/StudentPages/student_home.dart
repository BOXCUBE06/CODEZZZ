import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/student_provider.dart';
import 'student_form.dart';

class StudentHomeView extends StatelessWidget {
  const StudentHomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final studentProvider = context.watch<StudentProvider>();
    final double currentLat = 16.7208;
    final double currentLong = 121.6913;

    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "In case of emergency, press the button below.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
              const SizedBox(height: 40),

              // --- THE BIG RED BUTTON ---
              GestureDetector(
                onTap: studentProvider.status == EmergencyStatus.sending
                    ? null
                    : () {
                        studentProvider.sendPanicAlert(
                          lat: currentLat,
                          long: currentLong,
                          category: 'Other',
                          severity: 'severe',
                          description: 'PANIC BUTTON TRIGGERED',
                        );
                      },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    color: _getButtonColor(studentProvider.status),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _getButtonColor(
                          studentProvider.status,
                        ).withOpacity(0.4),
                        blurRadius: 30,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _getButtonIcon(studentProvider.status),
                        size: 80,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        _getButtonText(studentProvider.status),
                        style: const TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 30),

              TextButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const StudentFormPage(),
                    ),
                  );
                },
                icon: const Icon(Icons.edit_document, color: Colors.red),
                label: const Text(
                  "Report with Details",
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                  backgroundColor: Colors.red.shade50,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // --- STATUS MESSAGE ---
              if (studentProvider.errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Text(
                    studentProvider.errorMessage!,
                    style: const TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),

              if (studentProvider.status == EmergencyStatus.sent)
                const Text(
                  "HELP IS ON THE WAY",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),

              const SizedBox(height: 10),

              // --- DISPLAY LOCATION ---
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 20,
                ),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.gps_fixed, size: 16, color: Colors.green),
                        SizedBox(width: 8),
                        Text(
                          "Location Sharing Active",
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // Display the actual coordinates
                    Text(
                      "Lat: $currentLat, Long: $currentLong",
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- HELPERS ---
  Color _getButtonColor(EmergencyStatus status) {
    switch (status) {
      case EmergencyStatus.sending:
        return Colors.orange;
      case EmergencyStatus.sent:
        return Colors.green[600]!;
      case EmergencyStatus.failed:
        return Colors.grey[700]!;
      default:
        return Colors.red[600]!;
    }
  }

  String _getButtonText(EmergencyStatus status) {
    switch (status) {
      case EmergencyStatus.sending:
        return "SENDING";
      case EmergencyStatus.sent:
        return "SENT";
      case EmergencyStatus.failed:
        return "RETRY";
      default:
        return "PANIC";
    }
  }

  IconData _getButtonIcon(EmergencyStatus status) {
    switch (status) {
      case EmergencyStatus.sending:
        return Icons.wifi_tethering;
      case EmergencyStatus.sent:
        return Icons.check_circle;
      case EmergencyStatus.failed:
        return Icons.error_outline;
      default:
        return Icons.touch_app;
    }
  }
}
