import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart'; // Import Geolocator
import '../../../providers/student_provider.dart';
import '../components/live_map.dart';

class StudentFormPage extends StatefulWidget {
  const StudentFormPage({super.key});

  @override
  State<StudentFormPage> createState() => _StudentFormPageState();
}

class _StudentFormPageState extends State<StudentFormPage> {
  final _formKey = GlobalKey<FormState>();

  String _selectedCategory = 'Medical';
  String _selectedSeverity = 'moderate';
  final TextEditingController _descController = TextEditingController();

  // Location Variables (Nullable to indicate loading)
  double? _currentLat;
  double? _currentLong;
  bool _isLoadingLocation = true;

  final List<String> categories = [
    'Medical',
    'Fire',
    'Security',
    'Flood',
    'Other',
  ];
  final List<String> severities = ['severe', 'moderate', 'mild'];

  @override
  void initState() {
    super.initState();
    _getCurrentLocation(); // Fetch on load
  }

  // --- GET REAL LOCATION ---
  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      if (mounted) setState(() => _isLoadingLocation = false);
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        if (mounted) setState(() => _isLoadingLocation = false);
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      if (mounted) setState(() => _isLoadingLocation = false);
      return;
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      if (mounted) {
        setState(() {
          _currentLat = position.latitude;
          _currentLong = position.longitude;
          _isLoadingLocation = false;
        });
      }
    } catch (e) {
      print("GPS Error: $e");
      if (mounted) setState(() => _isLoadingLocation = false);
    }
  }

  @override
  void dispose() {
    _descController.dispose();
    super.dispose();
  }

  void _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    // Prevent submission if GPS failed
    if (_currentLat == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Waiting for location... please wait."),
          backgroundColor: Colors.orange,
        ),
      );
      // Try fetching again
      _getCurrentLocation();
      return;
    }

    final provider = context.read<StudentProvider>();

    await provider.sendPanicAlert(
      lat: _currentLat!, // Use real GPS
      long: _currentLong!,
      category: _selectedCategory,
      severity: _selectedSeverity,
      description: _descController.text.trim(),
    );

    if (mounted && provider.status == EmergencyStatus.sent) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Report Submitted Successfully"),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
      provider.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudentProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Report Incident",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.red[700],
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- 1. MAP SECTION ---
              const Text(
                "Confirm Location",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Container(
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                clipBehavior: Clip.antiAlias,
                // Only show map if we have location, else show spinner
                child: _isLoadingLocation
                    ? const Center(child: CircularProgressIndicator())
                    : (_currentLat != null)
                    ? const LiveMapWidget(showAllAlerts: false)
                    : const Center(child: Text("Location Disabled")),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    Icons.location_on,
                    size: 16,
                    color: _currentLat != null ? Colors.red : Colors.grey,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _isLoadingLocation
                        ? "Fetching GPS..."
                        : (_currentLat != null
                              ? "Lat: ${_currentLat!.toStringAsFixed(5)}, Lng: ${_currentLong!.toStringAsFixed(5)}"
                              : "GPS Unknown"),
                    style: const TextStyle(color: Colors.grey),
                  ),
                ],
              ),
              const Divider(height: 40),

              // --- 2. FORM DETAILS ---
              const Text(
                "Incident Details",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),

              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: "Category",
                  border: OutlineInputBorder(),
                ),
                items: categories
                    .map(
                      (cat) => DropdownMenuItem(value: cat, child: Text(cat)),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedCategory = val!),
              ),
              const SizedBox(height: 20),

              DropdownButtonFormField<String>(
                value: _selectedSeverity,
                decoration: const InputDecoration(
                  labelText: "Severity Level",
                  border: OutlineInputBorder(),
                ),
                items: severities
                    .map(
                      (sev) => DropdownMenuItem(
                        value: sev,
                        child: Row(
                          children: [
                            Icon(
                              Icons.circle,
                              color: _getSeverityColor(sev),
                              size: 14,
                            ),
                            const SizedBox(width: 10),
                            Text(sev[0].toUpperCase() + sev.substring(1)),
                          ],
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedSeverity = val!),
              ),
              const SizedBox(height: 20),

              TextFormField(
                controller: _descController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: "Description (Optional)",
                  hintText: "Describe the situation...",
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 30),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[700],
                  ),
                  // Disable button if loading or sending
                  onPressed:
                      (provider.status == EmergencyStatus.sending ||
                          _isLoadingLocation)
                      ? null
                      : _submitForm,
                  child: provider.status == EmergencyStatus.sending
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                          "SUBMIT REPORT",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),

              if (provider.errorMessage != null)
                Padding(
                  padding: const EdgeInsets.only(top: 16.0),
                  child: Text(
                    provider.errorMessage!,
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getSeverityColor(String severity) {
    switch (severity) {
      case 'severe':
        return Colors.red;
      case 'moderate':
        return Colors.orange;
      case 'mild':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}
