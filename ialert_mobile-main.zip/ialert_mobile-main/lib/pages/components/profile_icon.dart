import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../login_page.dart';

class ProfileIconButton extends StatelessWidget {
  const ProfileIconButton({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return PopupMenuButton<String>(
      icon: const Icon(Icons.account_circle, size: 30, color: Colors.white),
      onSelected: (value) {
        if (value == 'logout') {
          auth.logout();
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (route) => false,
          );
        } else if (value == 'profile') {
          _showProfileDialog(context, auth);
        }
      },
      itemBuilder: (BuildContext context) => [
        const PopupMenuItem(value: 'profile', child: Text('View Profile')),
        const PopupMenuItem(value: 'logout', child: Text('Logout')),
      ],
    );
  }

  void _showProfileDialog(BuildContext context, AuthProvider auth) {
    final user = auth.user;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(user?.name ?? "User Profile"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Role: ${user?.role.toUpperCase()}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text("ID: ${user?.loginId}"),

            if (auth.studentDetails != null) ...[
              const Divider(),
              Text("Dept: ${auth.studentDetails?.department}"),
              Text("Year: ${auth.studentDetails?.yearLevel}"),
            ],

            if (auth.responderDetails != null) ...[
              const Divider(),
              Text("Position: ${auth.responderDetails?.position}"),
              Text("Status: ${auth.responderDetails?.status}"),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Close"),
          ),
        ],
      ),
    );
  }
}
