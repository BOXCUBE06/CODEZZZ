import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart'; // Import Geolocator
import 'package:provider/provider.dart';
import '../../providers/responder_provider.dart';

class LiveMapWidget extends StatefulWidget {
  final bool showAllAlerts;

  const LiveMapWidget({super.key, required this.showAllAlerts});

  @override
  State<LiveMapWidget> createState() => _LiveMapWidgetState();
}

class _LiveMapWidgetState extends State<LiveMapWidget> {
  final MapController _mapController = MapController();

  // Default to ISU until GPS loads
  LatLng _currentLocation = const LatLng(16.7208, 121.6913);
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();

    if (widget.showAllAlerts) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<ResponderProvider>().fetchAlerts();
      });
    }
  }

  // --- GET REAL LOCATION ---
  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }

    if (permission == LocationPermission.deniedForever) return;

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      if (mounted) {
        setState(() {
          _currentLocation = LatLng(position.latitude, position.longitude);
          _isLoading = false;
        });
        // Move map to user immediately
        _mapController.move(_currentLocation, 16.0);
      }
    } catch (e) {
      print("Error getting location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    List<Marker> markers = [];

    // 1. ADD "MY LOCATION" MARKER
    markers.add(
      Marker(
        point: _currentLocation,
        width: 50,
        height: 50,
        child: const Column(
          children: [
            Icon(Icons.person_pin_circle, color: Colors.blue, size: 40),
          ],
        ),
      ),
    );

    // 2. ADD ALERTS (Red Icons)
    if (widget.showAllAlerts) {
      final provider = context.watch<ResponderProvider>();
      for (var alert in provider.alerts) {
        try {
          double lat = double.parse(alert.latitude);
          double lng = double.parse(alert.longitude);

          markers.add(
            Marker(
              point: LatLng(lat, lng),
              width: 50,
              height: 50,
              child: GestureDetector(
                onTap: () => _showAlertDetails(context, alert),
                child: Icon(
                  Icons.location_on,
                  color: alert.status == 'pending' ? Colors.red : Colors.orange,
                  size: 40,
                ),
              ),
            ),
          );
        } catch (e) {
          // ignore error
        }
      }
    }

    return Stack(
      children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: _currentLocation,
            initialZoom: 16.0,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.ialert.app',
            ),
            MarkerLayer(markers: markers),
            const RichAttributionWidget(
              attributions: [
                TextSourceAttribution('OpenStreetMap contributors'),
              ],
            ),
          ],
        ),

        // "Locate Me" Button
        Positioned(
          bottom: 20,
          right: 20,
          child: FloatingActionButton(
            backgroundColor: Colors.white,
            child: const Icon(Icons.my_location, color: Colors.blue),
            onPressed: () {
              _mapController.move(_currentLocation, 16.0);
            },
          ),
        ),
      ],
    );
  }

  // --- DETAIL POPUP (Keep existing code) ---
  void _showAlertDetails(BuildContext context, dynamic alert) {
    // ... (Your existing bottom sheet code) ...
    // If you lost it, I can paste it again below.
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        height: 250, // slightly taller
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: Colors.red, size: 30),
                const SizedBox(width: 10),
                Text(
                  alert.type.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: 10),
            Text(
              "Status: ${alert.status.toUpperCase()}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text("Location: ${alert.latitude}, ${alert.longitude}"),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[800],
                ),
                child: const Text(
                  "View Details",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
