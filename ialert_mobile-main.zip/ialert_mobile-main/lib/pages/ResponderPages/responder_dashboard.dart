import 'package:flutter/material.dart';
import '../components/profile_icon.dart';
import '../ResponderPages/responder_home.dart'; // The List of Alerts
import '../ResponderPages/responder_map.dart'; // The Map (All Alerts + Self)
import '../ResponderPages/responder_notification.dart'; // Notifications

class ResponderDashboard extends StatefulWidget {
  const ResponderDashboard({super.key});

  @override
  State<ResponderDashboard> createState() => _ResponderDashboardState();
}

class _ResponderDashboardState extends State<ResponderDashboard> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const ResponderHomeView(),
    const ResponderMapView(),
    const ResponderNotifView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Responder Duty",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue[800],
        centerTitle: true,
        actions: const [ProfileIconButton()],
      ),

      body: IndexedStack(index: _currentIndex, children: _pages),

      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        backgroundColor: Colors.blue.shade50,
        indicatorColor: Colors.blue.shade200,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.list_alt_outlined),
            selectedIcon: Icon(Icons.list_alt, color: Colors.blue),
            label: 'Dispatches',
          ),
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            selectedIcon: Icon(Icons.map, color: Colors.blue),
            label: 'Command Map',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_outlined),
            selectedIcon: Icon(Icons.notifications, color: Colors.blue),
            label: 'Updates',
          ),
        ],
      ),
    );
  }
}
