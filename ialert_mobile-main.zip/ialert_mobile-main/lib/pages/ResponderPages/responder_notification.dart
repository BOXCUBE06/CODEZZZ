import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/notification_provider.dart';

class ResponderNotifView extends StatefulWidget {
  const ResponderNotifView({super.key});

  @override
  State<ResponderNotifView> createState() => _ResponderNotifViewState();
}

class _ResponderNotifViewState extends State<ResponderNotifView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NotificationProvider>().fetchNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<NotificationProvider>();

    if (provider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (provider.notifications.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_none, size: 60, color: Colors.grey),
            SizedBox(height: 10),
            Text("No dispatch updates", style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => provider.fetchNotifications(),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: provider.notifications.length,
        itemBuilder: (context, index) {
          final notif = provider.notifications[index];

          return GestureDetector(
            onTap: () {
              if (!notif.isRead) {
                provider.markAsRead(notif.id);
              }
            },
            child: Card(
              color: notif.isRead ? Colors.white : Colors.blue[50],
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: CircleAvatar(
                  backgroundColor: _getTypeColor(notif.type).withOpacity(0.1),
                  child: Icon(
                    _getTypeIcon(notif.type),
                    color: _getTypeColor(notif.type),
                  ),
                ),
                title: Text(
                  notif.title,
                  style: TextStyle(
                    fontWeight: notif.isRead
                        ? FontWeight.normal
                        : FontWeight.bold,
                  ),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Text(notif.message),
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      _formatTime(notif.time),
                      style: const TextStyle(color: Colors.grey, fontSize: 10),
                    ),
                    if (!notif.isRead) ...[
                      const SizedBox(height: 4),
                      const Icon(Icons.circle, color: Colors.blue, size: 8),
                    ],
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // --- Helper Functions (Responder Style) ---

  Color _getTypeColor(String type) {
    if (type == 'alert' || type == 'emergency')
      return Colors.red; // Emergency is always Red
    if (type == 'success' || type == 'resolved') return Colors.green;
    return Colors.blue[700]!;
  }

  IconData _getTypeIcon(String type) {
    if (type == 'alert' || type == 'emergency') return Icons.priority_high;
    if (type == 'success' || type == 'resolved') return Icons.check_circle;
    return Icons.assignment;
  }

  String _formatTime(String rawDate) {
    try {
      DateTime date = DateTime.parse(rawDate);
      return "${date.hour}:${date.minute.toString().padLeft(2, '0')}";
    } catch (e) {
      return "Just now";
    }
  }
}
