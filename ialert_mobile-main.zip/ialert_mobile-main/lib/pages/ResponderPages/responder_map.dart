import 'package:flutter/material.dart';
import '../components/live_map.dart'; // Import Shared Map

class ResponderMapView extends StatelessWidget {
  const ResponderMapView({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const LiveMapWidget(showAllAlerts: true),

        Positioned(
          top: 20,
          left: 20,
          right: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.9),
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 8),
              ],
            ),
            child: const Row(
              children: [
                Icon(Icons.radar, color: Colors.blue),
                SizedBox(width: 8),
                Text(
                  "Scanning Area...",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Spacer(),
                Text(
                  "GPS Active",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
