import 'package:flutter/material.dart';
import '../services/notification_service.dart';
import '../models/notification_model.dart';

class NotificationProvider with ChangeNotifier {
  final NotificationService _service;

  List<AppNotification> _notifications = [];
  bool _isLoading = false;

  NotificationProvider(this._service);

  List<AppNotification> get notifications => _notifications;
  bool get isLoading => _isLoading;

  // Getter for the Red Dot count
  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  Future<void> fetchNotifications() async {
    _isLoading = true;
    // Don't notify listeners yet if you want to avoid screen flicker on silent refresh
    notifyListeners();

    try {
      final rawData = await _service.getNotifications();
      _notifications = rawData
          .map((json) => AppNotification.fromJson(json))
          .toList();
    } catch (e) {
      print("Error loading notifications: $e");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> markAsRead(int id) async {
    // 1. Optimistic Update (Update UI immediately)
    final index = _notifications.indexWhere((n) => n.id == id);
    if (index != -1) {
      // Create a copy with isRead = true
      _notifications[index] = AppNotification(
        id: _notifications[index].id,
        title: _notifications[index].title,
        message: _notifications[index].message,
        type: _notifications[index].type,
        time: _notifications[index].time,
        isRead: true, // <--- Set to true
      );
      notifyListeners(); // Updates the Unread Count in UI immediately
    }

    // 2. Send request to backend (Silent)
    await _service.markAsRead(id.toString());
  }
}
