import 'package:flutter/material.dart';
import '../services/responder_service.dart';
import '../models/alert_model.dart';

class ResponderProvider with ChangeNotifier {
  final ResponderService _responderService;

  List<Alert> _alerts = [];
  bool _isLoading = false;
  String? _errorMessage;

  ResponderProvider(this._responderService);

  List<Alert> get alerts => _alerts;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> fetchAlerts() async {
    _isLoading = true;
    notifyListeners();

    try {
      final rawData = await _responderService.getActiveAlerts();
      _alerts = rawData.map((json) => Alert.fromJson(json)).toList();
      _errorMessage = null;
    } catch (e) {
      print("DEBUG ERROR: $e"); // Check your console for this!
      _errorMessage =
          "Error: $e"; // <--- NEW: Shows the technical error on the phone screen
      _alerts = [];
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> acceptAlert(int id) async {
    try {
      final success = await _responderService.acceptAlert(id);
      if (success) {
        _alerts.removeWhere((a) => a.id == id);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
