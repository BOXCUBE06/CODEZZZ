import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';

enum AuthStatus { unauthenticated, authenticated, loading }

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();

  AuthStatus _status = AuthStatus.unauthenticated;
  User? _user;
  StudentDetails? _studentDetails;
  ResponderDetails? _responderDetails;
  String? _token;
  String? _errorMessage;

  AuthStatus get status => _status;
  User? get user => _user;
  String? get token => _token;
  String? get errorMessage => _errorMessage;
  StudentDetails? get studentDetails => _studentDetails;
  ResponderDetails? get responderDetails => _responderDetails;

  bool get isAuthenticated => _token != null;

  Future<bool> login({
    required String type,
    required String id,
    required String password,
  }) async {
    _status = AuthStatus.loading;
    _errorMessage = null;
    notifyListeners();

    final result = await _authService.login(id, password);

    if (result.containsKey('token')) {
      // SUCCESS
      _token = result['token'];
      _user = User.fromJson(result['user']);

      // Parse Role-Specific Details
      if (_user!.role == 'student' && result['details'] != null) {
        _studentDetails = StudentDetails.fromJson(result['details']);
        _responderDetails = null;
      } else if (_user!.role == 'responder' && result['details'] != null) {
        _responderDetails = ResponderDetails.fromJson(result['details']);
        _studentDetails = null;
      }

      _status = AuthStatus.authenticated;
      notifyListeners();
      return true;
    } else {
      // FAIL
      _status = AuthStatus.unauthenticated;
      _errorMessage = result['message'];
      notifyListeners();
      return false;
    }
  }

  // --- LOGOUT LOGIC ---
  void logout() {
    if (_token != null) {
      _authService.logout(_token!);
    }
    _token = null;
    _user = null;
    _studentDetails = null;
    _responderDetails = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}
