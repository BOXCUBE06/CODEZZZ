class AppNotification {
  final int id;
  final String title;
  final String message;
  final String type;
  final String time;
  final bool isRead;

  AppNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.type,
    required this.time,
    required this.isRead,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    final data = json['data'] ?? {};

    return AppNotification(
      id: json['id'] is int ? json['id'] : 0,
      title: data['title'] ?? 'Notification',
      message: data['message'] ?? 'No details',
      type: data['type'] ?? 'info',
      time: json['created_at'] ?? '',
      isRead: json['read_at'] != null,
    );
  }
}
