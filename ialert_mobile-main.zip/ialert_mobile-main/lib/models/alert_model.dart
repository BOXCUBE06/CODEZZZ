class Alert {
  final int id;
  final String type;
  final String latitude;
  final String longitude;
  final String status;
  final String time;
  final String description; // <--- NEW FIELD

  Alert({
    required this.id,
    required this.type,
    required this.latitude,
    required this.longitude,
    required this.status,
    required this.time,
    required this.description, // <--- NEW
  });

  factory Alert.fromJson(Map<String, dynamic> json) {
    return Alert(
      id: json['id'] is int ? json['id'] : int.parse(json['id'].toString()),
      type: json['category'] ?? json['type'] ?? 'Emergency',
      latitude: json['latitude'].toString(),
      longitude: json['longitude'].toString(),
      status: json['status'] ?? 'pending',
      time: json['created_at'] ?? '',
      // Capture the description, fallback to default text if empty
      description: json['description'] ?? 'No additional details provided.',
    );
  }
}
