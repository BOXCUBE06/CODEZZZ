import 'dart:convert';
import 'package:http/http.dart' as http;
import '../variables/variables.dart';

class ResponderService {
  final String token;

  ResponderService(this.token);

  // 1. Get List of ALL Alerts
  Future<List<dynamic>> getActiveAlerts() async {
    final url = Uri.parse('$baseUrl/responder/alerts?status=all');

    try {
      print("Fetching ALL alerts from: $url");

      final response = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      print("Response Code: ${response.statusCode}"); // Debugging
      // print("Response Body: ${response.body}");    // Uncomment to see raw data

      if (response.statusCode == 200) {
        final dynamic json = jsonDecode(response.body);

        if (json is List) {
          return json;
        } else if (json is Map<String, dynamic> && json.containsKey('data')) {
          return json['data'];
        }
        return [];
      }
      return [];
    } catch (e) {
      print("Error fetching alerts: $e");
      return [];
    }
  }

  // 2. Accept Alert
  Future<bool> acceptAlert(int alertId) async {
    final url = Uri.parse('$baseUrl/alerts/$alertId/accept');

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      return response.statusCode == 200;
    } catch (e) {
      print("Error accepting alert: $e");
      return false;
    }
  }
}
