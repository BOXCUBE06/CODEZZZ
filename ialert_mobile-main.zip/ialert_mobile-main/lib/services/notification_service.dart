import 'dart:convert';
import 'package:http/http.dart' as http;
import '../variables/variables.dart';

class NotificationService {
  final String token;

  NotificationService(this.token);

  Future<List<dynamic>> getNotifications() async {
    final url = Uri.parse('$baseUrl/notifications');

    try {
      final response = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final dynamic json = jsonDecode(response.body);

        // 🔴 FIX: Check if it is a List OR a Map before accessing keys
        if (json is List) {
          return json; // It is already a list [ ... ]
        } else if (json is Map<String, dynamic> && json.containsKey('data')) {
          return json['data']; // It is { "data": [ ... ] }
        }

        return [];
      }
      return [];
    } catch (e) {
      print("Error fetching notifications: $e");
      return [];
    }
  }

  Future<bool> markAsRead(dynamic id) async {
    // Ensure ID is a string for the URL
    final url = Uri.parse('$baseUrl/notifications/$id/read');
    try {
      await http.put(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );
      return true;
    } catch (e) {
      return false;
    }
  }
}
